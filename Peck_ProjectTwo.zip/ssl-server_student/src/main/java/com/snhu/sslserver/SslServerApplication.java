package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;



@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController{

	String finalHashString;
	
	//FIXME:  Add hash function to return the checksum value for the data string that should contain your name.    
	private String createHashFunction(String dataToHash) {
        try {
        	//Create the message digest with the SHA-256 hash function
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            
            //Update it to bytes
            md.update(dataToHash.getBytes());
            
            //Convert to byte array
            byte[] digest = md.digest();
            
            StringBuilder hexString = new StringBuilder();
            
            //for loop to convert from byte to hex then add to string
            for (byte b : digest) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            System.err.println("Algorithm not found: " + e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
	@RequestMapping("/hash")
	public String myHash(){
        String data = "Hello Michael Peck Jr.!";
        
        // Call the helper method to get the hash
        String finalHashString = createHashFunction(data);
        
        String transformation = "AES/CBC/PKCS5Padding";
        String algorithmName = null;

        try {
        	//Grab the cipher instance
            Cipher cipher = Cipher.getInstance(transformation);
            
            //get the corresponding algorithm
            algorithmName = cipher.getAlgorithm();
        } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
       
        return "<p> Hello World! Welcome to Artemis Financial Secure Site" + "<p>data:"+data + "<p> Algorithm Name: " + algorithmName + "<p> Hash value: " + finalHashString;
    }
}
